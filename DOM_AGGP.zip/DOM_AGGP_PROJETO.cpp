//DOM_Ativi01 - Projeto Dominó - etapa 3
//15/08/2024 - Grupo: AGGP

//Alexandre Maciano de Oliveira 
//Gabriel Manganiello Terra
//Gabriel Mechi Lima
//Pedro Marinho Machado

/*Nessa estapa iremos embaralhar as peças e distribuir as peças para
ambos os jogadores, também fazendo com que a primeira jogada seja definida, que permita 
que o jogador compre uma peça caso necessario. O sistema também irá verificar se a jogada feita 
é válida.
*/
#include "DOM_AGGP_Model.cpp"
#include "DOM_AGGP_Controller.cpp"
main(){
	gerarPecas();
	jogar();
}
