//DOM_Ativi01 - Projeto Dominó - etapa 3
//15/08/2024 - Grupo: AGGP

//Alexandre Maciano de Oliveira 
//Gabriel Manganiello Terra
//Gabriel Mechi Lima
//Pedro Marinho Machado

#include <iostream>
#include "DOM_AGGP_View.h"
int ladoA,ladoB;

void fClear(){
    char carac;
    while ((carac = fgetc(stdin)) != EOF && carac != '\n') {}
}
void mostrarMesa(int pecasnamesa){
	printf("\n\nMESA:\n");
	for(int i=0;i<pecasnamesa;i++){
		printf("[%d|%d]", mesa[i].ladoE,mesa[i].ladoD);
	}
}
void limparTela(void){
	system("cls");
}
void jogarPeca(void){
	printf("\nDigite a peca que deseja jogar (formato [a|b])");
	fClear();
	scanf("[%d|%d]", &ladoA, &ladoB);
}
int jogadaOption(void){
	printf("\n\nO que deseja fazer?\n");
	printf("1. Comprar peca\n");
	printf("2. Jogar uma peca\n");
	int jogadaop;
	scanf("%d", &jogadaop);
	return jogadaop;
}

void showPlayerPieces(char turno){
	printf("\n\nVEZ DO JOGADOR %c: (pecas disponiveis)\n", turno);
	for (int i=0;i<28;i++){
		if (pieces[i].status==turno){
			printf("[%d|%d]",pieces[i].numberA,pieces[i].numberB);
		}
	}
}




void primeiraPeca(char turno){
	printf("\n\nMESA: (Jogador %c)\n", turno);
	printf("[%d|%d]", mesa[0].ladoE, mesa[0].ladoD);
}
int mostrarPecas(void){
	for (int i=0; i<28; i++)
		printf("[%d|%d]", pieces[i].numberA, pieces[i].numberB);
	return 0;
}
void errorMessage(void){
	printf("ERROR");
}
void espaco(void){
	printf("\n");
}
int menuInicial(void){
	int option;
	printf("BEM VINDO(A) AO JOGO DE DOMINO!\n");
	printf("Selecione uma das seguintes opcoes:\n");
	printf("1. Iniciar jogo modo Arcade. *AINDA NAO DISPONIVEL*\n");
	printf("2. Iniciar jogo multiplayer (2 jogadores).\n");
	printf("3. Mostrar embaralhamento atual.\n");
	scanf("%d", &option);
	return option;
}
