//DOM_Ativi01 - Projeto Dominó - etapa 3
//15/08/2024 - Grupo: AGGP

//Alexandre Maciano de Oliveira 
//Gabriel Manganiello Terra
//Gabriel Mechi Lima
//Pedro Marinho Machado

#include <iostream>

int mostrarPecas();
