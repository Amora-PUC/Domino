//DOM_Ativi01 - Projeto Domino - etapa 4
//28/08/2024 - Grupo: AGGP

//Alexandre Maciano de Oliveira 
//Gabriel Manganiello Terra
//Gabriel Mechi Lima
//Pedro Marinho Machado

void gerarPecas(void);



