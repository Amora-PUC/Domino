//DOM_Ativi01 - Projeto Domino - etapa 4
//28/08/2024 - Grupo: AGGP

//Alexandre Maciano de Oliveira 
//Gabriel Manganiello Terra
//Gabriel Mechi Lima
//Pedro Marinho Machado

#include <iostream>

int mostrarPecas();
void espaco(int qntd);
void errorMessage(int id);
void fClear();
